def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def _max_pool2d(input: Tensor,
    kernel_size: List[int],
    stride: Optional[List[int]]=None,
    padding: List[int]=[0, 0],
    dilation: List[int]=[1, 1],
    ceil_mode: bool=False,
    return_indices: bool=False) -> Tensor:
  if torch.__is__(stride, None):
    stride0 = annotate(List[int], [])
  else:
    stride0 = unchecked_cast(List[int], stride)
  _0 = torch.max_pool2d(input, kernel_size, stride0, padding, dilation, ceil_mode)
  return _0
def softmax(input: Tensor,
    dim: Optional[int]=None,
    _stacklevel: int=3,
    dtype: Optional[int]=None) -> Tensor:
  _1 = __torch__.torch.nn.functional._get_softmax_dim
  if torch.__is__(dim, None):
    dim1 = _1("softmax", torch.dim(input), _stacklevel, )
    dim0 = dim1
  else:
    dim0 = unchecked_cast(int, dim)
  if torch.__is__(dtype, None):
    ret = torch.softmax(input, dim0)
  else:
    dtype0 = unchecked_cast(int, dtype)
    ret = torch.softmax(input, dim0, dtype0)
  return ret
def _get_softmax_dim(name: str,
    ndim: int,
    stacklevel: int) -> int:
  _2 = "Implicit dimension choice for {} has been deprecated. Change the call to include dim=X as an argument."
  torch.warn(torch.format(_2, name), stacklevel)
  if torch.eq(ndim, 0):
    _3 = True
  else:
    _3 = torch.eq(ndim, 1)
  if _3:
    _4 = True
  else:
    _4 = torch.eq(ndim, 3)
  if _4:
    ret = 0
  else:
    ret = 1
  return ret
