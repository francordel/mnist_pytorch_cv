class Preprocessing(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.Preprocessing,
    x: Tensor) -> Tensor:
    x0 = torch.div(x, 255.)
    x1 = torch.div(torch.sub(x0, 0.13070000000000001), 0.30809999999999998)
    return torch.unsqueeze(x1, 1)
class CNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1 : __torch__.torch.nn.modules.container.Sequential
  conv2 : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  fc : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.CNN,
    x: Tensor) -> Tensor:
    conv1 = self.conv1
    x2 = (conv1).forward(x, )
    conv2 = self.conv2
    x3 = (conv2).forward(x2, )
    x4 = torch.view(x3, [(torch.size(x3))[0], -1])
    fc = self.fc
    return (fc).forward(x4, )
class Postprocessing(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  softmax : __torch__.torch.nn.modules.activation.Softmax
  def forward(self: __torch__.Postprocessing,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    softmax = self.softmax
    _0 = (x, (softmax).forward(x, ), torch.argmax(x, 1))
    return _0
